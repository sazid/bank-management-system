package m6;

public class UserLoginInfo {
    public String username;
    public String status;
    public String name;
}
